/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.mackenzie.fci.ticketmachine.exception;

/**
 *
 * @author 1146132
 */
public class SaldoInsuficienteException extends Exception {
}
