package br.mackenzie.fci.ticketmachine.exception;

public class SaldoInsuficienteException extends Exception {

}
