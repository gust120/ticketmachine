package br.mackenzie.fci.ticketmachine.exception;

public class PapelMoedaInvalidaException extends Exception {

}
