import java.util.Iterator;

import junit.framework.Assert;

import org.junit.Test;

import br.mackenzie.fci.ticketmachine.core.PapelMoeda;
import br.mackenzie.fci.ticketmachine.core.TicketMachine;
import br.mackenzie.fci.ticketmachine.exception.PapelMoedaInvalidaException;
import br.mackenzie.fci.ticketmachine.exception.SaldoInsuficienteException;

public class Teste {

	@Test
	public void test() throws SaldoInsuficienteException,
			PapelMoedaInvalidaException {
		TicketMachine tm = new TicketMachine(2);
		Assert.assertEquals(0, tm.getSaldo());
		tm.inserir(10);
		tm.inserir(20);
		tm.inserir(100);
		Assert.assertEquals(130, tm.getSaldo());
		String aux = tm.imprimir();
		Assert.assertEquals(
				"*****************\n*** R$ 128,00 ****\n*****************\n",
				aux);

		PapelMoeda pm;
		Iterator<PapelMoeda> itTroco = tm.getTroco(); 
		while (itTroco.hasNext()) {
			pm = itTroco.next();
			System.out.print(pm.getQuantidade()+" ");
			System.out.println(pm.getValor());
		}

	}
}
